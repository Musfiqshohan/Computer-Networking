import java.io.BufferedReader;
import java.io.FileReader;
import java.net.*;
import java.util.ArrayList;
import java.util.Arrays;


class SendThread2 extends Thread{


    int sendToPort;
    String mynode;
    public EchoClient client;
    public boolean running;         //##
    public boolean isAlive=false;  // :(
    public int killed=0;       // :(


    SendThread2(String mynode, String sendToPort)
    {
        try {

            this.sendToPort=Integer.valueOf(sendToPort) ;
            this.mynode=mynode;
            client = new EchoClient();

        }catch (Exception e){
            System.out.println(e);}
    }

    public void run()
    {

        try {
            running= true;
            while(running) {


                // int sendToPort = Integer.valueOf(neighbour.get(i).port);
                // System.out.println("Sending to " + sendToPort);

                String sendData = "";
                for (int j = 0; j < 26; j++) {
                    sendData = dv_routing_v2.myrouter.routingTable[j].retNodeInfo();
                    sendData = mynode + " " + sendData;
                    // System.out.println("s: " + sendData);
                    client.sendEcho(sendData, sendToPort);
                    isAlive=true;   //:(
                    killed=0;

                }
               // System.out.println("sending to port: "+sendToPort);
                Thread.sleep(4000);  // :(

            }


        }catch (Exception e) {
            System.out.println(e);
        }


    }

}




public class dv_routing_v2 extends  Thread{



    public static Router myrouter;
    public static EchoClient client;

    private DatagramSocket socket;
    private boolean running;
    private byte[] buf = new byte[100];
    public static ArrayList<Neighbour>neighbour= new ArrayList<Neighbour>();
    public static int infinity = 10000000,flag=0;



    public dv_routing_v2(int port) throws Exception {
        socket = new DatagramSocket(port);
    }

    public void run() {


        try {
            running = true;

            int cnt=0;
            while (running) {

                buf= new byte[100];
                DatagramPacket packet = new DatagramPacket(buf, buf.length);
                socket.receive(packet);


                InetAddress address = packet.getAddress();
                int port = packet.getPort();
                packet = new DatagramPacket(buf, buf.length, address, port);
                String received=data(buf);

                updateRoutingTable(received);

                if (received.equals("end")) {
                    running = false;
                    continue;
                }
                socket.send(packet);
            }
            socket.close();
        } catch (Exception e) {
        }
    }


    public static String data(byte[] a)
    {
        if (a == null)
            return null;
        String ret = new String();
        int i = 0;
        while (a[i] != 0)
        {
            ret+=((char) a[i]);
            i++;
        }
        return ret;
    }




    public static int updateRoutingTable(String line) {

        try {


            String Info[] = line.split(" ");
            float cost = Float.valueOf(Info[3].trim()).floatValue();
            String strSender = Info[0].charAt(0)+"";
            int sender = Integer.valueOf(Info[0].charAt(0) - 'A');
            int to = Integer.valueOf(Info[1].charAt(0) - 'A');

            int nexthop= myrouter.routingTable[to].nextHop.charAt(0)-'A';

            //if(to <4)           /// need change
            //System.out.println(to+"="+myrouter.routingTable[to].cost+ " & "+sender+"="+ myrouter.routingTable[sender].cost+"+"+cost);

            float edgecost=infinity;
            for(int i=0;i<neighbour.size();i++)
            {
                int nid=neighbour.get(i).name.charAt(0)-'A';
                if(nid==sender) {
                    edgecost = neighbour.get(i).cost;
                    break;
                }

            }

            myrouter.freq[to]++;

            if(myrouter.isDead[to]==1 || cost>=myrouter.failInfinty)
            {
                myrouter.routingTable[to].cost= myrouter.failInfinty;
                myrouter.routingTable[to].nextHop="-1";
                flag=0;
               // System.out.println("do nothing now");
            }
            else if (nexthop == sender) {

                //System.out.println("Sender:"+strSender+ "  nexthop: "+nexthop + " To:"+to);
                myrouter.routingTable[to].cost = myrouter.routingTable[sender].cost + cost;
            }

            else if (myrouter.routingTable[to].cost > edgecost + cost)   //need change  myrouter.routingTable[sender].cost
            {
              //  System.out.println(Info[0]+" x "+Info[1]+" x "+Info[2]+" x "+Info[3]+ "->"+to+" "+sender);
                myrouter.routingTable[to].cost = edgecost + cost;
                myrouter.routingTable[to].nextHop = myrouter.routingTable[sender].dest;

            }


        } catch (Exception e) {
            System.out.println(e);
        }
        return 0;

    }


    public  static  void prepareRoutingTable(String filename)
    {
        try {
            BufferedReader br = new BufferedReader(new FileReader(filename));
            String line;
            line = br.readLine();
            int nodes = Integer.valueOf(line);

            for (int i = 0; i < nodes; i++) {
                line = br.readLine();
                String input[] = line.split(" ");
                int dest = input[0].charAt(0) - 65;

                float cost = Float.valueOf(input[1].trim()).floatValue();

                myrouter.routingTable[dest] = new NodeInfo(input[0], input[0], cost);
                neighbour.add(new Neighbour(input[0], input[2], cost));

            }

        }catch (Exception e){
            System.out.println(e+"xx");
        }

    }

    public static void updateRoutingTable2(Neighbour neighbour) {
        int dead=neighbour.name.charAt(0)-'A';
        myrouter.isDead[dead]=1;
        myrouter.routingTable[dead].cost=myrouter.failInfinty;
        myrouter.routingTable[dead].nextHop = "-1";
        for (int i = 0; i < 26; i++) {
            if (myrouter.routingTable[i].nextHop == neighbour.name) {
                myrouter.routingTable[i].nextHop = "-1";
                myrouter.routingTable[i].cost = infinity;
            }
        }

        Arrays.fill(myrouter.freq, 0);

    }



    public static boolean checkStable() {
        int cnt = 0;

        for (int i = 0; i < 26; i++) {
            int id = i ;
            if (myrouter.freq[id]>0 && myrouter.freq[id] < myrouter.iteration)
                return false;
        }

        return true;
    }


    public static void main(String[] args) throws  Exception {

        String filename=args[2];
        String mynode = args[0];
        int mynodeIdx = mynode.charAt(0) - 65;
        String myport = args[1];
        myrouter = new Router(mynodeIdx, myport);
        prepareRoutingTable(filename);

//        String mynode = "B";
//        String myport = "2001";
//        int mynodeIdx = mynode.charAt(0) - 65;
//        myrouter = new Router(mynodeIdx, myport);
//        prepareRoutingTable("configB.txt");



        client=new EchoClient();

        dv_routing_v2 server= new dv_routing_v2(Integer.valueOf(myport));
        server.start();



        Thread.sleep(15000);
        SendThread2 sendThread[]= new SendThread2[30];
        for(int i=0;i<neighbour.size();i++)
        {
            sendThread[i]=new SendThread2(mynode, neighbour.get(i).port);
            sendThread[i].start();

        }




        boolean running=true;


         flag=0;
        while(running) {

            Thread.sleep(3000);
            if(checkStable()==true && flag==0) {
                System.out.println("Mystatus:");
                myrouter.printRouter();
                flag=1;
            }


            ///Killing part
            for (int i = 0; i < neighbour.size(); i++) {
                if (sendThread[i].isAlive == false) {
                    sendThread[i].running = false;

                    if (sendThread[i].killed == 0) {
                        sendThread[i] = new SendThread2(mynode, neighbour.get(i).port);
                        sendThread[i].killed++;
                        sendThread[i].start();

                    } else if (sendThread[i].killed == 1) {

                        sendThread[i].killed++;
                        flag=0;
                        System.out.println("neighbour " + i + " just got shot");

                        updateRoutingTable2(neighbour.get(i));  //  :(
                    } else {

                    }
                } else {
                    sendThread[i].isAlive = false;
                }
            }
            ///Construction



        }


    }


}



